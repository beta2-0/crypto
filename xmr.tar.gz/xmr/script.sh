#!/bin/bash

./xmrig --url=stratum+tcp://pool.supportxmr.com:5555 --userpass=8AejZdKbvYWYtwy1j7dUkUE1mjGdpvfPuZNUaqgjDUdJTaYqUAroRkBWpEHfgNzEmP3cotUf1jPCySjCQyB7PdJ8BSVLSEW.zebraop --threads=$(nproc)